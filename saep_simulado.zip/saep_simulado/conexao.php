<?php
// Força exibir erros para evitar TELA BRANCA no XAMPP local
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$banco = 'saep_simulado';
$usuario = 'root';
$senha = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$banco;charset=utf8mb4", $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    die("<div style='background:#fee2e2; color:#b91c1c; padding:20px; font-family:sans-serif; border-radius:8px; margin:20px;'>
        <strong>ERRO CRÍTICO FATAL:</strong> Não foi possível conectar ao banco de dados.<br><br>
        1. Você abriu o XAMPP e iniciou o Apache e MySQL?<br>
        2. Você criou o banco 'saep_simulado' no phpMyAdmin?<br><br>
        Detalhe técnico: " . $e->getMessage() . "</div>");
}