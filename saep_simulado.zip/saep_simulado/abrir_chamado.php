<?php
session_start();
if (empty($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
require __DIR__ . '/conexao.php';
$erro = '';

$equipamentos = $pdo->query('SELECT id, nome FROM equipamentos')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipamento_id = filter_input(INPUT_POST, 'equipamento_id', FILTER_VALIDATE_INT);
    $prioridade = $_POST['prioridade'] ?? '';
    $descricao = trim($_POST['descricao'] ?? '');

    if (!$equipamento_id || $descricao === '' || !in_array($prioridade, ['Baixa', 'Média', 'Alta'])) {
        $erro = 'Preencha todos os campos corretamente.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO chamados (equipamento_id, usuario_id, descricao, prioridade, status) VALUES (?, ?, ?, ?, "Aberto")');
        $stmt->execute([$equipamento_id, $_SESSION['usuario_id'], $descricao, $prioridade]);
        header('Location: painel.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>TechMaq - Novo Chamado</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="container container-sm">
    <h2>Registrar Manutenção</h2>
    <?php if ($erro): ?><div class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
    
    <form method="post">
        <div class="form-group">
            <label>Equipamento com Defeito</label>
            <select name="equipamento_id" required>
                <option value="">Selecione na lista...</option>
                <?php foreach ($equipamentos as $e): ?>
                    <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label>Nível de Prioridade</label>
            <select name="prioridade" required>
                <option value="Baixa">Baixa (Pode aguardar)</option>
                <option value="Média">Média (Atenção em breve)</option>
                <option value="Alta">Alta (Parada de linha imediata)</option>
            </select>
        </div>
        
        <div class="form-group">
            <label>Descrição do Problema</label>
            <textarea name="descricao" rows="4" required placeholder="Ex: Vazamento de óleo na lateral direita..."></textarea>
        </div>
        
        <button type="submit" class="btn">Salvar Registro</button>
        <a href="painel.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
</body>
</html>