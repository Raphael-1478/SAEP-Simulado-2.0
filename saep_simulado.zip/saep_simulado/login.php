<?php
session_start();
require __DIR__ . '/conexao.php';
$erro = ''; $sucesso = '';

if (isset($_GET['cadastro'])) $sucesso = 'Conta criada com sucesso! Faça login.';
if (isset($_GET['erro'])) $erro = 'E-mail ou senha incorretos.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    $stmt = $pdo->prepare('SELECT id, nome, senha FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        session_regenerate_id(true);
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        header('Location: painel.php');
        exit;
    } else {
        header('Location: login.php?erro=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>TechMaq - Acesso</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="container container-sm">
    <div style="text-align: center; margin-bottom: 2rem;">
        <h2 style="margin-bottom: 0.5rem; color: var(--primary);">TechMaq</h2>
        <p style="color: var(--text-light);">Acesse o painel de manutenção</p>
    </div>
    
    <?php if ($erro): ?><div class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
    <?php if ($sucesso): ?><div class="alerta alerta-sucesso"><?= htmlspecialchars($sucesso) ?></div><?php endif; ?>
    
    <form method="post">
        <div class="form-group">
            <label>E-mail Corporativo</label>
            <input type="email" name="email" required placeholder="seu@email.com">
        </div>
        <div class="form-group">
            <label>Senha</label>
            <input type="password" name="senha" required placeholder="••••••••">
        </div>
        <button type="submit" class="btn">Entrar no Sistema</button>
        <a href="cadastro.php" class="btn btn-secondary">Criar nova conta</a>
    </form>
</div>
</body>
</html>