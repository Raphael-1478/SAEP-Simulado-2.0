<?php
session_start();
if (empty($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
require __DIR__ . '/conexao.php';

try {
    $sql = 'SELECT c.id, c.descricao, c.prioridade, c.status, e.nome AS equipamento 
            FROM chamados c 
            JOIN equipamentos e ON c.equipamento_id = e.id 
            ORDER BY c.id DESC';
    $chamados = $pdo->query($sql)->fetchAll();
} catch (PDOException $e) {
    die("Erro ao buscar chamados. Você executou o banco.sql corretamente? " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>TechMaq - Painel</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="container">
    <div class="header-flex">
        <div>
            <h2 style="margin:0;">Painel de Chamados</h2>
            <p style="color: var(--text-light); font-size:0.9rem;">Técnico: <?= htmlspecialchars($_SESSION['usuario_nome']) ?></p>
        </div>
        <div>
            <a href="abrir_chamado.php" class="btn" style="width: auto; margin:0; margin-right: 10px;">+ Novo Chamado</a>
            <a href="logout.php" class="btn btn-danger" style="width: auto; margin:0;">Sair</a>
        </div>
    </div>
    
    <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr>
                    <th>Nº</th>
                    <th>Equipamento</th>
                    <th>Problema</th>
                    <th>Prioridade</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$chamados): ?>
                    <tr><td colspan="5" style="text-align: center; color: var(--text-light); padding: 2rem;">Nenhum chamado aberto.</td></tr>
                <?php else: ?>
                    <?php foreach ($chamados as $c): 
                        $badge_class = 'badge-baixa';
                        if ($c['prioridade'] === 'Média') $badge_class = 'badge-media';
                        if ($c['prioridade'] === 'Alta') $badge_class = 'badge-alta';
                    ?>
                        <tr>
                            <td style="font-weight: 600; color: var(--primary);">#<?= $c['id'] ?></td>
                            <td style="font-weight: 500;"><?= htmlspecialchars($c['equipamento']) ?></td>
                            <td><?= htmlspecialchars($c['descricao']) ?></td>
                            <td><span class="badge <?= $badge_class ?>"><?= htmlspecialchars($c['prioridade']) ?></span></td>
                            <td><span style="font-weight: 600; font-size: 0.85rem; color: #4b5563;">◉ <?= htmlspecialchars($c['status']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>